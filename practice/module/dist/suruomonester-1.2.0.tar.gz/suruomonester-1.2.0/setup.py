from distutils.core import setup

setup(
    name="suruomonester",
    version='1.2.0',
    py_modules=['suruomonester'],
    author="suruomo",
    author_email="suruomo@hotmail.com",
    url="http://github.com/suruomo",
    description="A simple printer for nested lists",
)